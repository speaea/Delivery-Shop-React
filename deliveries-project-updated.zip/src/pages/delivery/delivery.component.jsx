import { useEffect, useState } from 'react';
import { NavLink, useParams } from 'react-router-dom';
import { isMobilePhone } from 'validator';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

const Delivery = ({ deliveries, onClick }) => {
  const params = useParams();
  const [delivery, setDelivery] = useState({
    id: null,
    name: '',
    description: '',
    address: '',
    phone: '',
  });

  const validation = {
    name: {
      label: 'שם',
      required: true,
      maxLength: 50,
    },
    description: {
      label: 'תיאור',
      required: true,
      maxLength: 500,
    },
    address: {
      label: 'כתובת',
      required: true,
      maxLength: 100,
    },
    phone: {
      label: 'פלאפון',
      required: true,
      maxLength: 20,
      cb: (value) => isMobilePhone(value),
    },
  };

  useEffect(() => {
    if (params.id) {
      const delivery = deliveries.find(
        (delivery) => delivery.id.toString() === params.id.toString()
      );
      setDelivery(delivery);
    }
  }, [params, deliveries]);

  if (params.id && (!delivery || !delivery.id)) {
    return <>המשלוח לא נמצא</>;
  }

  const validateDelivery = (deliveryData) => {
    const keys = Object.keys(validation);
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      if (validation[key].required && !deliveryData[key]) {
        return {
          error: true,
          message: `חסר ${[validation[key].label]}`,
        };
      }

      if (
        validation[key].maxLength &&
        deliveryData[key].length > validation[key].maxLength
      ) {
        return {
          error: true,
          message: `${validation[key].label} ארוך מדי`,
        };
      }

      if (validation[key].cb && !validation[key].cb(deliveryData[key])) {
        return {
          error: true,
          message: `${validation[key].label} לא תקין`,
        };
      }
    }

    return {
      success: true,
    };
  };

  const handleSubmit = (deliveryData) => {
    const { id: deliveryId, ...data } = deliveryData;

    const { error, message } = validateDelivery(data);
    if (error) {
      alert(message);
      return;
    }

    if (deliveryId) {
      onClick(deliveryId, data);
    } else {
      onClick(delivery);
    }
  };

  return (
    <>
      <NavLink to='/'>חזרה לרשימת משלוחים</NavLink>
      <h1>{delivery.id ? `עריכת משלוח - ${delivery.id}` : 'הוספת משלוח'}</h1>
      <Form
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '1rem',
          paddingRight: '2rem',
          paddingLeft: '2rem',
        }}
      >
        <Form.Group controlId='name'>
          <Form.Label>שם</Form.Label>
          <Form.Control
            type='text'
            placeholder='הכנס שם'
            maxLength={20}
            defaultValue={delivery.name}
            onChange={(e) => setDelivery({ ...delivery, name: e.target.value })}
          />
        </Form.Group>
        <Form.Group controlId='description'>
          <Form.Label>תיאור</Form.Label>
          <Form.Control
            as={'textarea'}
            placeholder='הכנס תיאור'
            defaultValue={delivery.description}
            onChange={(e) =>
              setDelivery({ ...delivery, description: e.target.value })
            }
          />
        </Form.Group>
        <Form.Group controlId='address'>
          <Form.Label>כתובת</Form.Label>
          <Form.Control
            type='text'
            placeholder='הכנס כתובת'
            defaultValue={delivery.address}
            onChange={(e) =>
              setDelivery({ ...delivery, address: e.target.value })
            }
          />
        </Form.Group>
        <Form.Group controlId='phone'>
          <Form.Label>פלאפון</Form.Label>
          <Form.Control
            type='text'
            placeholder='הכנס פלאפון'
            defaultValue={delivery.phone}
            onChange={(e) =>
              setDelivery({ ...delivery, phone: e.target.value })
            }
          />
        </Form.Group>
        <Button variant='primary' onClick={() => handleSubmit(delivery)}>
          {delivery.id ? 'עדכן משלוח' : 'הוסף משלוח'}
        </Button>
      </Form>
    </>
  );
};

export default Delivery;
