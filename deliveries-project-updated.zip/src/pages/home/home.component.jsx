import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import Form from 'react-bootstrap/Form';

import {
  DeliveriesContainer,
  SelectedContainer,
  ActionsContainer,
} from './home.styles';

const Home = ({ deliveries, onDelete }) => {
  const [selectedDeliveries, setSelectedDeliveries] = useState([]);

  const handleDeliverySelection = (id) => {
    if (selectedDeliveries.includes(id)) {
      setSelectedDeliveries(
        selectedDeliveries.filter((delivery) => delivery !== id)
      );
      return;
    }

    setSelectedDeliveries([...selectedDeliveries, id]);
  };

  const handleSelectAll = (value) => {
    if (value) {
      setSelectedDeliveries(deliveries.map((delivery) => delivery.id));
      return;
    }

    setSelectedDeliveries([]);
  };

  return (
    <div>
      <h1>כל המשלוחים</h1>
      <NavLink to={'/add-delivery'}>לחץ כאן כדי להוסיף משלוח</NavLink>
      {deliveries.length === 0 ? (
        <p>אין משלוחים</p>
      ) : (
        <DeliveriesContainer>
          {selectedDeliveries.length > 0 && (
            <SelectedContainer>
              <span>מספר משלוחים שנבחרו: {selectedDeliveries.length}</span>
              <Button
                size='sm'
                variant='danger'
                onClick={() => onDelete(selectedDeliveries)}
              >
                מחק
              </Button>
            </SelectedContainer>
          )}
          <Table striped bordered hover>
            <thead>
              <tr>
                <th
                  style={{
                    verticalAlign: 'middle',
                    textAlign: 'center',
                  }}
                >
                  <Form.Check
                    checked={
                      selectedDeliveries.length > 0 &&
                      selectedDeliveries.length === deliveries.length
                    }
                    onChange={(event) => handleSelectAll(event.target.checked)}
                  />
                </th>
                <th>מס'</th>
                <th>שם</th>
                <th>כתובת</th>
                <th>צור קשר</th>
                <th
                  style={{
                    width: '30%',
                  }}
                >
                  תיאור
                </th>
                <th>פעולות</th>
              </tr>
            </thead>
            <tbody>
              {deliveries.map((delivery) => (
                <tr key={delivery.id}>
                  <td
                    style={{
                      verticalAlign: 'middle',
                      textAlign: 'center',
                    }}
                  >
                    <Form.Check
                      checked={selectedDeliveries.includes(delivery.id)}
                      onChange={(event) => handleDeliverySelection(delivery.id)}
                    />
                  </td>
                  <td>{delivery.id}</td>
                  <td>{delivery.name}</td>
                  <td>{delivery.address}</td>
                  <td>
                    <a href={`tel:${delivery.phone}`}>{delivery.phone}</a>
                  </td>
                  <td>{delivery.description}</td>
                  <td>
                    <ActionsContainer>
                      <NavLink to={`/delivery/${delivery.id}`}>
                        <Button variant='primary' size='sm'>
                          ערוך
                        </Button>
                      </NavLink>
                      <Button
                        size='sm'
                        variant='danger'
                        onClick={() => onDelete([delivery.id])}
                      >
                        מחק
                      </Button>
                    </ActionsContainer>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </DeliveriesContainer>
      )}
    </div>
  );
};

export default Home;
