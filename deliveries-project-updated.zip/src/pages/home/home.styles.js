import styled from 'styled-components';

export const DeliveriesContainer = styled.div`
  padding: 1rem;
`;

export const ActionsContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

export const SelectedContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;

  & > p {
    font-size: 1.2rem;
  }
`;
