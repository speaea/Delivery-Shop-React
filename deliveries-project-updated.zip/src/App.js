import { useEffect, useState, useMemo } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';

import Home from './pages/home/home.component';
import Delivery from './pages/delivery/delivery.component';

import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  const defaultDeliveries = useMemo(() => [{
    id: 1,
    name: 'משלוח 1',
    description: 'כסא ילדים',
    address: 'גבעת רם 1',
    phone: '0521234567',
  }, {
    id: 2,
    name: 'משלוח 2',
    description: 'רחפן',
    address: 'חיפה 2',
    phone: '0521234222',
  }, {
    id: 3,
    name: 'משלוח 3',
    description: 'ספה',
    address: 'דיזנגוף 3',
    phone: '0521234333',
  }], []);

  const [deliveries, setDeliveries] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const deliveriesInStorage = localStorage.getItem('deliveries');
    if (deliveriesInStorage) {
      setDeliveries(JSON.parse(deliveriesInStorage));
    } else {
      localStorage.setItem('deliveries', JSON.stringify(defaultDeliveries));
    }
  }, [defaultDeliveries]);

  const addDelivery = (data) => {
    do {
      data.id = deliveries ? deliveries[deliveries.length - 1].id + 1 : 1;
    } while (deliveries.find((delivery) => delivery.id === data.id) !== undefined);

    const newDelivery = data;
    const updatedDeliveries = [...deliveries, newDelivery];
    setDeliveries(updatedDeliveries);
    localStorage.setItem('deliveries', JSON.stringify(updatedDeliveries));

    navigate('/');
  };

  const updateDelivery = (id, data) => {
    const updatedDeliveries = deliveries.map((delivery) => {
      if (delivery.id.toString() === id.toString()) {
        return {
          ...delivery,
          ...data,
        };
      }
      return delivery;
    });
    setDeliveries(updatedDeliveries);
    localStorage.setItem('deliveries', JSON.stringify(updatedDeliveries));

    navigate('/');
  };

  const deleteDelivery = (ids) => {
    const idsStr = ids.map((id) => id.toString());
    const updatedDeliveries = deliveries.filter((delivery) => !idsStr.includes(delivery.id.toString()));
    setDeliveries(updatedDeliveries);
    localStorage.setItem('deliveries', JSON.stringify(updatedDeliveries));
  };

  return (
    <>
      <Routes>
        <Route path="/" element={<Home deliveries={deliveries} onDelete={deleteDelivery} />} />
        <Route path="/add-delivery" element={<Delivery deliveries={deliveries} onClick={addDelivery} />} />
        <Route path="/delivery/:id" element={<Delivery deliveries={deliveries} onClick={updateDelivery} />} />
      </Routes>
    </>
  );
}

export default App;
